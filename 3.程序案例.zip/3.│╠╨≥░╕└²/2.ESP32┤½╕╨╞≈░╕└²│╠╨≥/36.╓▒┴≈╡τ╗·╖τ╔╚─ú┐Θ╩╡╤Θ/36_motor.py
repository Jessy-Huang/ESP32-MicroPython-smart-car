#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：36_motor.py
#  版本：V2.0
#  author: zhulin
#  说明：风扇电机实验
#####################################################
from machine import Pin
from utime import sleep


# 设置风扇管脚PIN
Makerobo_MotorPin1   = 22
pin_2 = 15


def Makerobo_setup():
    global motor
    motor = Pin(Makerobo_MotorPin1,Pin.OUT)  # 风扇设置为输出模式  
    global motor2
    motor2 = Pin(pin_2,Pin.OUT)
# 风扇电机控制函数
def Makerobo_motor(direction):
    # 开启风扇
    if direction == 1:
        motor.value(1) # 输出高电平
        motor2.value(0)
        print ("Makerobo Open")

    # 关闭风扇
    if direction == 0:
        # 关闭风扇
        motor.value(0) # 输出低电平
        motor2.value(1)
        print ("Stop")

def Makerobo_main():

    fs_directions = {'Open': 1, 'STOP': 0} # 定义开和关
    while True:
        # 风扇开
        Makerobo_motor(fs_directions['Open'])
        sleep(5)
        # 风扇关
        Makerobo_motor(fs_directions['STOP'])
        sleep(5)

   
# 程序入口
if __name__ == '__main__':
    Makerobo_setup()
    Makerobo_main()

    