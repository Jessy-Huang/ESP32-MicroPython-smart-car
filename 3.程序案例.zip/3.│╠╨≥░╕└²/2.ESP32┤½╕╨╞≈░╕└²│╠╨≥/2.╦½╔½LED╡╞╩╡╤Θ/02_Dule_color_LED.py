#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：02_Dule_color_LED.py
#  版本：V2.0
#  author: zhulin
# 说明：双色LED灯实验
#---------------------------------------
from machine import Pin, PWM
from time import sleep


colors = [0xFF00, 0x00FF, 0x0FF0, 0xF00F] # 定义颜色值
makerobo_pins = (4, 27)  # PIN管脚字典

p_R = PWM(Pin(makerobo_pins[0]))  # 定义红色LED PWM
p_G = PWM(Pin(makerobo_pins[1]))  # 定义绿色LED PWM

# 定义频率
p_R.freq(1000) #设置红色LED工作频率为1K
p_G.freq(1000) #设置绿色LED工作频率为1K

def makerobo_pwm_map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def makerobo_set_Color(col):   # 例如:col = 0x1122
    R_val = col  >> 8
    G_val = col & 0x00FF
    # 把0-255的范围同比例扩大到占空比介于0至1023间
    R_val = round(makerobo_pwm_map(R_val, 0, 255, 0, 1023))
    G_val = round(makerobo_pwm_map(G_val, 0, 255, 0, 1023))

    p_R.duty(R_val)     # 改变占空比
    p_G.duty(G_val)     # 改变占空比

# 调用循环函数
def makerobo_loop():
    while True:
        for col in colors:
            makerobo_set_Color(col)
            sleep(0.5)

# 程序入口
if __name__ == "__main__":
    makerobo_loop()  # 调用循环函数

