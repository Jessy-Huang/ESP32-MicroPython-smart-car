#!/usr/bin/python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：31_mpu6050.py
#  版本：V2.0
#  author: zhulin
# 说明：31_mpu6050.py
#####################################################
from machine import Pin
import utime
import math
import mpu6050

# MPU6050的SDA接GP26,SCL接GP25
mpu = mpu6050.MPU6050()
mpu.setSampleRate(200) # 设置采样率
mpu.setGResolution(2)  # 设置g分辨率

# 均值处理
def averageMPU( count, timing_ms):
    gx = 0
    gy = 0
    gz = 0
    gxoffset =  0.07
    gyoffset = -0.04
    for i in range(count):
        g=mpu.readData()
        # offset mpu
        gx = gx + g.Gx - gxoffset
        gy = gy + g.Gy - gyoffset
        gz = gz + g.Gz
        utime.sleep_ms(timing_ms)
    return gx/count, gy/count, gz/count

# 循环函数
def loop():
    while True:
        gx, gy, gz = averageMPU(20,5)
        # calculate vector dimension
        vdim = math.sqrt( gx*gx + gy*gy + gz*gz)

        # get x angle
        rad2degree= 180 / math.pi
        angleX =  rad2degree * math.asin(gx / vdim)
        angleY =  rad2degree * math.asin(gy / vdim)
        # 获取X，Y的倾斜角度
        print('Makerobo angleY = {0:0.2f} °'.format(-angleY))
        print('         angleX = {0:0.2f} °'.format(-angleX))

# 程序入口
if __name__ == '__main__':
    loop()
