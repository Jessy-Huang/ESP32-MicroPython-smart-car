#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：05_relay.py
#  版本：V2.0
#  author: zhulin
# 说明：继电器模块实验
#---------------------------------------
from machine import Pin
from time import sleep

makerobo_RelayPin = 27    # 定义继电器管脚为Pin27

# 初始化工作
def makerobo_setup():
    global Relay
    Relay = Pin(makerobo_RelayPin,Pin.OUT) # 设置Pin模式为输出模式
    Relay.value(0) # 关闭继电器

# 循环函数
def makerobo_loop():
    while True:
        # 继电器打开
        Relay.value(1)
        sleep(0.5)  # 延时500ms

        # 继电器关闭
        Relay.value(0)
        sleep(0.5) # 延时500ms

# 程序入口
if __name__ == '__main__':

    makerobo_setup()           #  初始化
    makerobo_loop()        #  调用循环函数

