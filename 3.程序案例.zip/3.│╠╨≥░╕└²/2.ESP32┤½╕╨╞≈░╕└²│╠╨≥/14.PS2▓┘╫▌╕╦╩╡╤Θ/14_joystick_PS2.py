#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：14_joystick_PS2.py
#  版本：V2.0
#  author: zhulin
# 说明：PS2操作杆实验
#####################################################
from machine import Pin,ADC
from time import sleep

makerobo_VRX_ADC = 34 # ADC6复用管脚为GP34
makerobo_VRY_ADC = 35 # ADC7复用管脚为GP35
makerobo_SW_ADC =  36 # ADC0复用管脚为GP36



# 初始化
def makerobo_setup():
    global makerobo_state  # 状态变量
    global adcx
    global adcy
    global adcsw

    adcx = ADC(Pin(makerobo_VRX_ADC))
    adcx.atten(ADC.ATTN_11DB)

    adcy = ADC(Pin(makerobo_VRY_ADC))
    adcy.atten(ADC.ATTN_11DB)

    adcsw = ADC(Pin(makerobo_SW_ADC))
    adcsw.atten(ADC.ATTN_11DB)

def makerobo_map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
#
# 方向判断函数
def makerobo_direction():
    state = ['home', 'up', 'down', 'left', 'right', 'pressed']  # 方向状态信息
    i = 0

    adc_X = round(makerobo_map(adcx.read(), 0, 4095, 0, 255))
    adc_Y = round(makerobo_map(adcy.read(), 0, 4095, 0, 255))
    adc_SW = round(makerobo_map(adcsw.read(), 0, 4095, 0, 255))
    #print("adc_x=%d,adc_y=%d,adc_sw=%d"%(adc_X,adc_Y,adc_SW))
    sleep(0.1)
    if  adc_X <= 30:
        i = 1 # up方向
    elif adc_X >= 255:
        i = 2 # down方向
    elif adc_Y >= 255:
        i = 3 # left方向
    elif adc_Y <= 30:
        i = 4 # right方向
    elif adc_SW == 0:#and adc_Y ==128:
        i = 5 # Button按下
    # home位置
    elif adc_X - 125 < 15 and adc_X - 125 > -15 and adc_Y -125 < 15 and adc_Y -125 > -15 and adc_SW == 255:
        i = 0

    return state[i]   # 返回状态

# 循环函数
def makerobo_loop():
    makerobo_status = ''    # 状态值赋空值
    while True:
        makerobo_tmp = makerobo_direction()   # 调用方向判断函数
        if makerobo_tmp != None and makerobo_tmp != makerobo_status:  # 判断状态是否发生改变
            print (makerobo_tmp) # 打印出方向位
            makerobo_status = makerobo_tmp # 把当前状态赋给状态值，以防止同一状态多次打印

# 程序入口
if __name__ == '__main__':
    makerobo_setup()  # 初始化
    makerobo_loop()   # 调用循环函数


