#!/usr/bin/python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：30_barometer.py
#  版本：V2.0
#  author: zhulin
# 说明：BMP280气压传感器实验
#####################################################
from machine import Pin,I2C
from bmp280 import BMP280
from time import sleep

# 实例化BMP280 对象
bus = I2C(1,sda= Pin(26), scl= Pin(25), freq=400000)
makerobo_sensor = BMP280(bus)

# 循环函数
def loop():
    while True:
        print('Makerobo Temp = {0:0.2f} *C'.format(makerobo_sensor.temperature))    # 获取温度
        print('Makerobo Pressure = {0:0.2f} Pa'.format(makerobo_sensor.pressure))   # 读取气压值
        sleep(0.5)                                                                  # 延时500ms

# 程序入口
if __name__ == '__main__':
    loop()
