#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：01.onboard_LED.py
#  版本：V2.0
#  author: zhulin
# 说明：板载LED灯闪烁
#---------------------------------------
from machine import Pin
import utime 
# 定义板载LED 的GPIO口为GP25管脚，并设置为输出模式
led_onboard = Pin(22,Pin.OUT)
light = Pin(32,Pin.IN)

if __name__ == '__main__':
    # 循环函数
    while True:
        if light.value() == 0:
            led_onboard.value(0) # 输出高电平
        else:
            led_onboard.value(1) # 输出高电平




#utime.sleep_ms(100)
