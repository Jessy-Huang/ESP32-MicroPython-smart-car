#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：25_ds18b20.py
#  版本：V2.0
#  author: zhulin
# 说明： DS18B20数字温度传感器实验
#####################################################
import machine, onewire, ds18x20, time

ds_pin = machine.Pin(13)   # 定义DS18B20
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))

roms = ds_sensor.scan()           # 扫描是否存在DS18B20设备
print('Found a ds18x20 device')

# 循环函数
def makerobo_loop():
    while True:
      ds_sensor.convert_temp()
      time.sleep_ms(750)
      for rom in roms:
        print(ds_sensor.read_temp(rom))  # 打印出温度值
      time.sleep(2)                      # 延时2s时间

# 程序入口
if __name__ == '__main__':
    makerobo_loop()             # 调用循环函数
