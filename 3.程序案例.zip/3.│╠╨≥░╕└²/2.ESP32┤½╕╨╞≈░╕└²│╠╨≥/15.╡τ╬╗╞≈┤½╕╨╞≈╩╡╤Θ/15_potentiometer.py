#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：15_potentiometer.py
#  版本：V2.0
#  author: zhulin
# 说明：电位器实验
#####################################################
from machine import Pin,ADC,PWM
from time import sleep

makerobo_R = 27        # 红色LED管脚
makerobo_pot = 34       # ADC6复用管脚为GP34

# 初始化工作
def makerobo_setup():
    global p_R
    global pot_ADC

    p_R = PWM(Pin(makerobo_R),freq=2000) #设置红色LED工作频率为2K
    pot_ADC = ADC(Pin(makerobo_pot))
    pot_ADC.atten(ADC.ATTN_11DB)      # 11dB 衰减, 最大输入电压约3.6v

def makerobo_pwm_map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# 无限循环
def makerobo_loop():
    makerobo_status = 1 # 给状态变量赋1值
    while True:   # 无限循环
        print ('Potentiometer Value:', pot_ADC.read()) # 获取ADC0上的值，读取电位器模拟量值并打印出该值
        makerobo_Value=round(makerobo_pwm_map(pot_ADC.read(), 0, 4095, 0, 1023))
        p_R.duty(makerobo_Value)  # 控制AOUT输出电平控制LED灯
        sleep(0.2)               # 延时200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup() # 初始化函数
    makerobo_loop()  # 无限循环
