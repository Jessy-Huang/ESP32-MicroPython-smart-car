#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：09_vibration_switch.py
#  版本：V2.0
#  author: zhulin
#  说明：振动传感器实验
#####################################################
from machine import Pin
from time import sleep

makerobo_VibratePin = 26 #振动传感器Pin端口

makerobo_Rpin       = 4  #红色LEDPin端口
makerobo_Gpin       = 27 #绿色LEDPin端口

clb_tmp = 0

# 初始化设置
def makerobo_setup():
    global Vibrate
    global p_R
    global p_G
    p_R = Pin(makerobo_Rpin,Pin.OUT) # 设置红色LED管脚为输出模式
    p_G = Pin(makerobo_Gpin,Pin.OUT) # 设置绿色LED管脚为输出模式
    Vibrate = Pin(makerobo_VibratePin, Pin.IN, Pin.PULL_UP) # 设置BtnPin管脚为输入模式，上拉至高电平(3.3V)

# 双色LED模块驱动子函数
def double_colorLED(x):
    if x == 0:                         # x为0时，开启红色LED灯
        p_R.value(1)
        p_G.value(0)
    if x == 1:                         # x为1时，开启绿色LED灯
        p_R.value(0)
        p_G.value(1)

# 打印信息,打印出振动传感器的状态
def makerobo_Print(x):
    global clb_tmp
    if x != clb_tmp:
        if x == 0:
            print('******************')
            print('* Makerobo    ON *')
            print('******************')

        if x == 1:
            print('*******************')
            print('* OFF  Makerobo   *')
            print('*******************')
        clb_tmp = x

# 循环函数
def makerobo_loop():
    clb_state = 0
    while True:
        if Vibrate.value() == 1:  # 判断振动传感的值，如果为0有振动产生
            clb_state = clb_state + 1           # 振动传感器状态加1
            if clb_state > 1:                   # 状态发生改变判断
                clb_state = 0                   # 状态值复位

            double_colorLED(clb_state)          # 控制双色LED模块
            makerobo_Print(clb_state)           # 打印出状态
            sleep(1)                       # 延时1s

# 程序入口
if __name__ == '__main__':
    makerobo_setup()       # 初始化设置
    makerobo_loop()        # 循环函数
