#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：19_photoresistor.py
#  版本：V2.0
#  author: zhulin
#  说明：光敏电阻传感器实验
#####################################################
from machine import Pin,ADC
from time import sleep

makerobo_photo = 34 # ADC6复用管脚为GP34


# 初始化工作
def makerobo_setup():
    global photo_ADC
    photo_ADC = ADC(Pin(makerobo_photo))     # ADC6复用管脚为GP34
    photo_ADC.atten(ADC.ATTN_11DB)           # 11dB 衰减, 最大输入电压约3.6v

# 循环函数
def makerobo_loop():
    makerobo_status = 1 # 状态值
    # 无限循环
    while True:
        print ('Photoresistor Value: ', photo_ADC.read()) # 读取ADC6的值16-bits，获取光敏模拟量值
        sleep(0.2)                                            # 延时200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup() # 地址设置
    makerobo_loop()  # 调用无限循环
