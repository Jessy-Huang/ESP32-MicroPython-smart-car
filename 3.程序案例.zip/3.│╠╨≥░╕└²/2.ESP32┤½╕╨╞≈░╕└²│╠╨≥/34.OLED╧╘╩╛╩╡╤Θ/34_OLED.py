#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：34_OLED.py
#  版本：V2.0
#  author: zhulin
# 说明：OLED显示实验
#  基本使用方法：
# oled.pixel(x,y,z)      x y处画点
#oled.text("Hello World!",0,9,1)  写文字
# oled.line(x,y,x2,y2,c) 直线
# oled.vline(x,y,l,c)
# oled.hline(x,y,l,c)
#####################################################
from machine import SoftI2C,Pin
from ssd1306 import SSD1306_I2C  #I2C的oled选该方法



#i2c=I2C(0,sda=Pin(0), scl=Pin(1), freq=400000)
i2c = SoftI2C(sda=Pin(13), scl=Pin(14))   #I2C初始化：sda--> 13, scl --> 14
oled = SSD1306_I2C(128, 64, i2c) #你的OLED分辨率，使用I2C
oled.fill(1) #清空屏幕

oled.show()
oled.fill(0)
oled.show()

oled.text("Hello World!",0,9,1)
oled.text("Makerobo Kit!",0,18,1)
oled.show()

