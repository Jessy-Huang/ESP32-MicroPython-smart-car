#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：08_tilt_switch.py
#  版本：V2.0
#  author: zhulin
# 说明：倾斜传感器实验
#####################################################
from machine import Pin
from time import sleep

makerobo_TiltPin = 26  # 倾斜传感器Pin端口

makerobo_Rpin   = 4   # 红色LEDPin端口
makerobo_Gpin   = 27   # 绿色LEDPin端口
n = 1
# 初始化GPIO口
def makerobo_setup():
    global Tilt
    global p_R
    global p_G
    p_R = Pin(makerobo_Rpin,Pin.OUT) # 设置红色LED管脚为输出模式
    p_G = Pin(makerobo_Gpin,Pin.OUT) # 设置绿色LED管脚为输出模式
    Tilt = Pin(makerobo_TiltPin, Pin.IN, Pin.PULL_UP) # 设置BtnPin管脚为输入模式，上拉至高电平(3.3V)
    # 中断函数，当轻触按键按下时，调用detect函数
    Tilt.irq(trigger=Pin.IRQ_FALLING,handler=makerobo_detect)

# 双色LED模块驱动子函数
def double_colorLED():
    global n
    if n == 1:
        p_R.value(1)
        p_G.value(0)
        n = 0
    else:
        n = 1
        p_R.value(0)
        p_G.value(1)



# 打印函数，显示出按键按下
def makerobo_Print(x):
    if x == 0:
        print('***************************************')
        print('***** makerobo ESP32 Kit Tilt!        *')
        print('***************************************')

# 中断函数，有按键按下时，响应中断函数
def makerobo_detect(chn):
    double_colorLED()                  # 调用双色LED驱动函数
    makerobo_Print(Tilt.value())       # 打印出GPIO的状态

# 循环函数
def makerobo_loop():
    while True:
        pass

# 程序入口
if __name__ == '__main__':
    makerobo_setup()           # 初始化GPIO口
    makerobo_loop()            # 循环函数
