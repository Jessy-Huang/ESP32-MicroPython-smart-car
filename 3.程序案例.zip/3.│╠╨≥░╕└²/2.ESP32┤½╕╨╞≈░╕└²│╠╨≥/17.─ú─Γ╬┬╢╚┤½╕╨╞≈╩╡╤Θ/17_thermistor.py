#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：17_thermistor.py
#  版本：V2.0
#  author: zhulin
# 说明：模拟温度传感器实验
#####################################################
from machine import Pin,ADC
from time import sleep
import math

makerobo_DO = 27   # 温度传感器Do管脚
makerobo_temp = 34 # ADC6复用管脚为GP34

# 初始化设置
def makerobo_setup():
    global temp_DO
    global temp_ADC
    temp_DO =  Pin(makerobo_DO,Pin.IN) # 温度传感器DO端口设置为输入模式
    temp_ADC = ADC(Pin(makerobo_temp)) # ADC6复用管脚为GP34
    temp_ADC.atten(ADC.ATTN_11DB)      # 11dB 衰减, 最大输入电压约3.6v

# 打印出温度传感器的提示信息
def makerobo_Print(x):
    if x == 1:     # 正合适
        print ('')
        print ('***********')
        print ('* Better~ *')
        print ('***********')
        print ('')
    if x == 0:    # 太热
        print ('')
        print ('************')
        print ('* Too Hot! *')
        print ('************')
        print ('')



# 循环函数
def makerobo_loop():
    makerobo_status = 1   # 状态值
    makerobo_tmp = 1      # 当前值
    while True:
        makerobo_analogVal = temp_ADC.read()                    # 读取ADC6上的模拟值
        makerobo_Vr = 3.3 * float(makerobo_analogVal) / (4095) # 转换到5V范围
        makerobo_Rt = 10000 * makerobo_Vr / (3.3 - makerobo_Vr)
        makerobo_temp = 1/(((math.log(makerobo_Rt / 10000)) / 3950) + (1 / (273.15+25)))
        makerobo_temp = makerobo_temp - 273.15
        print ('temperature = ', makerobo_temp, 'C')

        makerobo_tmp = temp_DO.value()      # 读取温度传感器数字端口

        if makerobo_tmp != makerobo_status: # 判断状态值发生改变
            makerobo_Print(makerobo_tmp)    # 打印出温度传感器的提示信息
            makerobo_status = makerobo_tmp  # 把当前状态值设置为比较状态值，避免重复打印；

        sleep(0.2)                     # 延时 200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup()  #初始化程序
    makerobo_loop()   #循环函数
