#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：33_tracking.py
#  版本：V2.0
#  author: zhulin
#  说明：循迹传感器实验
#   红外传感器，二极管不断发射红外线，遇到白色反射回来，红外接收管饱和，输出低电平，否则输出高电平
#####################################################
from machine import Pin
import utime

makerobo_TrackPin = 18 # 循迹传感器PIN管脚

#  初始化设置函数
def makerobo_setup():
    global Track
    # 设置makerobo_TrackPin管脚为输入模式，上拉至高电平(3.3V)
    Track = Pin(makerobo_TrackPin,Pin.IN,Pin.PULL_UP)

# 循环函数
def makerobo_loop():
    while True:
        if Track.value() == 0:  # 检测到白色线
            print ('Makerobo White line is detected')
        else:
            print ('...Makerobo Black line is detected') # 检测到黑色线

        utime.sleep(0.2) # 延时200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup()   # 调用初始化程序
    makerobo_loop()    # 调用循环函数


