#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：32_ds1302.py
#  版本：V2.0
#  author: zhulin
# 说明：DS1302实时时钟模块试验
#      ds1302 Module           Pico
#        VCC ------------------ 5 V (Must be 5v)
#        GND ------------------ GND
#        CLK ---------------- GPIO18
#        DAT ---------------- GPIO19
#        RST ---------------- GPIO23
'''
'''
ds.Year()     # 获取今天的年份
ds.Month()    # 获取今天的月份
ds.Day()      # 获取今天的日期
ds.Weekday()  # 获取当前周几
ds.Hour()     # 获取当前小时
ds.Minute()   # 获取当前分钟
ds.Second()   # 获取当前的秒
'''
#####################################################
from machine import Pin
import DS1302
from utime import sleep

ds = DS1302.DS1302(Pin(18),Pin(19),Pin(23)) # 实例化ds1302对象

# 设置时间
ds.DateTime([2021,6,24,5,17,33,28])

# 循环函数
def makerobo_loop():
    while True:
        print(ds.DateTime())
        sleep(1)

# 程序入口
if __name__ == '__main__':
    makerobo_loop()         # 循环函数
