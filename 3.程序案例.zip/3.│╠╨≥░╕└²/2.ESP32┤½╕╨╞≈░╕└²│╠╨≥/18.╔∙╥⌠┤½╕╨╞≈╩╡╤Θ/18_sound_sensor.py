#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：18_sound_sensor.py
#  版本：V2.0
#  author: zhulin
# 说明：声音传感器实验
#####################################################
from machine import Pin,ADC
from time import sleep

makerobo_sound = 34 # ADC6复用管脚为GP34

# 初始化工作
def makerobo_setup():
    global sound_ADC
    sound_ADC = ADC(Pin(makerobo_sound))     # ADC6复用管脚为GP34
    sound_ADC.atten(ADC.ATTN_11DB)           # 11dB 衰减, 最大输入电压约3.6v

def makerobo_map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# 循环函数
def makerobo_loop():
    makerobo_count = 0                                        # 计数值
    while True:                                               # 无限循环
        makerobo_voiceValue = round(makerobo_map(sound_ADC.read(), 0, 4095, 0, 255)) # 读取ADC6上的模拟值
        if makerobo_voiceValue:                                # 当声音值不为0
            print ("Sound Value:", makerobo_voiceValue)        # 打印出声音值
            if makerobo_voiceValue > 25:                      # 如果声音传感器读取值小于80
                print ("Voice detected! ", makerobo_count)     # 打印出计数值
                makerobo_count += 1                            # 计数值累加
            sleep(0.2)                                         # 延时 200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup() # 初始化程序
    makerobo_loop()  # 循环函数
