#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：22_TM1637.py
#  版本：V2.0
#  author: zhulin
# 说明：TM1637四位数码管实验
# 使用说明:tm.numbers(12, 59) tm.number(-123) tm.temperature(24) 显示温度
#      all LEDS on "88:88"
#      tm.write([127, 255, 127, 127])
#      all LEDS off
#      tm.write([0, 0, 0, 0])
#      一个列表每个代表一个led晶体管
#      数字8 由7个led管组成
#      8： 由8个led管组成
#---------------------------------------
import tm1637
from machine import Pin
from utime import sleep
# 定义管脚 clk 接GP0 DIO 接GP1
tm = tm1637.TM1637(clk=Pin(16), dio=Pin(17))

n = 0
while True:
    # 定义一个计数器 1秒变化一次
    tm.number(n)
    n = n + 1
    sleep(1)


