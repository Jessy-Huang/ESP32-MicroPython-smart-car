#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：37_StepperMotor.py
#  版本：V2.0
#  author: zhulin
#  说明：步进电机实验
'''
s1.step(100)
s1.step(100,-1)
s1.angle(180)
s1.angle(360,-1)
'''
# step设置509差不多angle设置360
#####################################################
import Stepper
from machine import Pin
from utime import sleep

s1 = Stepper.create(Pin(22,Pin.OUT),Pin(32,Pin.OUT),Pin(25,Pin.OUT),Pin(26,Pin.OUT), delay=2)


# 步进电机旋转
def makerobo_rotary(clb_direction):
    if(clb_direction == 'a'):     # 逆时针旋转
        s1.angle(360,-1)
    elif(clb_direction == 'c'):    # 顺时针旋转
        s1.angle(360)
# 循环函数
def makerobo_loop():
    while True:
        clb_direction = input('Makerobo select motor direction a=anticlockwise, c=clockwise: ')
        if(clb_direction == 'c'):
            print('Makerobo motor running clockwise\n')       # 顺时针旋转
            break
        elif(clb_direction == 'a'):
            print('Makerobo motor running anti-clockwise\n')  # 逆时针旋转
            break
        else:
            print('Makerobo input error, please try again!')  # 输入错误，再次输入
    while True:
        makerobo_rotary(clb_direction)       # 让步进电机旋转



# 程序入口
if __name__ == '__main__':
    makerobo_loop()  # 循环函数
