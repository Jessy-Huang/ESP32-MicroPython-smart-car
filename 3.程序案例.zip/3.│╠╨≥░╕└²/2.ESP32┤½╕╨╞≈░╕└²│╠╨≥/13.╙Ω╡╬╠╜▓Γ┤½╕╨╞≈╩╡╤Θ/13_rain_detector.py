#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：13_rain_detector.py
#  版本：V2.0
#  author: zhulin
#  说明：雨滴探测传感器实验
#####################################################
from machine import Pin,ADC
from time import sleep

makerobo_DO = 27        # 雨滴传感器数字管脚
makerobo_ADC = 34       # ADC6复用管脚为GP34

# GPIO口定义
def makerobo_setup():
    global raind_ADC
    global raind_DO

    raind_DO = Pin(makerobo_DO,Pin.IN)   # 设置雨滴传感器管脚为输入模式
    raind_ADC = ADC(Pin(makerobo_ADC))        # ADC6复用管脚为GP34
    raind_ADC.atten(ADC.ATTN_11DB)      # 11dB 衰减, 最大输入电压约3.6v


# 打印出雨滴传感器提示信息
def makerobo_Print(x):
    if x == 1:          # 没有雨滴
        print ('')
        print ('   ************************')
        print ('   * makerobo Not raining *')
        print ('   ************************')
        print ('')
    if x == 0:          # 有雨滴
        print ('')
        print ('   **********************')
        print ('   * makerobo Raining!! *')
        print ('   **********************')
        print ('')

# 循环函数
def makerobo_loop():
    makerobo_status = 1      # 雨滴传感器状态
    while True:
        print (raind_ADC.read())         # 打印出ADC0的模拟量数值

        makerobo_tmp = raind_DO.value()      # 读取数字IO口电平，读取数字雨滴传感器DO端口
        if makerobo_tmp != makerobo_status:  # 状态发生改变
            makerobo_Print(makerobo_tmp)   # 打印出雨滴传感器检测信息
            makerobo_status = makerobo_tmp # 状态值重新赋值
        sleep(0.2)                         # 延时200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup()   # GPIO定义
    makerobo_loop()    # 调用循环函数


