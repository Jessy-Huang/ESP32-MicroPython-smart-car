#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：28_ir_obstacle.py
#  版本：V2.0
#  author: zhulin
#  说明：红外避障传感器模块
#####################################################
from machine import Pin
from time import sleep

makerobo_ObstaclePin = 27       # 红外避障传感器管脚PIN

def makerobo_setup():
    global ir_Obstacle
    # 设置makerobo_ObstaclePin管脚为输入模式，上拉至高电平(3.3V)
    ir_Obstacle = Pin(makerobo_ObstaclePin,Pin.IN,Pin.PULL_UP)

# 无限循环
def makerobo_loop():
    while True:
        if (0 == ir_Obstacle.value()):  # 检测到障碍物
            print ("Makerobo Detected Barrier!")     # 打印出障碍物信息
            sleep(0.2)                               # 延时200ms

# 程序入口
if __name__ == '__main__':
    makerobo_setup()       # 初始化设置
    makerobo_loop()        # 无限循环
