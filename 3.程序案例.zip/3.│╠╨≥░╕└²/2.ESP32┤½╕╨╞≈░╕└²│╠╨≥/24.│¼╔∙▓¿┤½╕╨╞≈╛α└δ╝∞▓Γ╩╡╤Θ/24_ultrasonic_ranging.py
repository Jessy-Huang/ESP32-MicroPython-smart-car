#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：24_ultrasonic_ranging.py
#  版本：V2.0
#  author: zhulin
# 说明： 超声波传感器距离检测实验
# 注意事项：超声波模块的供电电压必须采用5V供电！
#####################################################
from hcsr04 import HCSR04
from time import sleep

sensor = HCSR04(trigger_pin=4, echo_pin=27) # 定义超声波模块Tring控制管脚及超声波模块Echo控制管脚


# 循环函数
def makerobo_loop():
    while True:
        us_dis = sensor.distance_cm()   # 获取超声波计算距离 ，也可以调用sensor.distance_mm() 得到mm值
        print (us_dis, 'cm')            # 打印超声波距离值
        print ('')
        sleep(0.3)                      # 延时300ms

# 程序入口
if __name__ == "__main__":
    makerobo_loop() # 调用循环函数
