#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：10_passive_buzzer.py
#  版本：V2.0
#  author: zhulin
#  说明：无源蜂鸣器实验
#  这是一个无源蜂鸣器模块的程序
#  它可以播放简单的歌曲。
#  你可以尝试自己创作歌曲!
#####################################################
from machine import Pin, PWM
from utime import sleep

makerobo_Buzzer = 18            # 无源蜂鸣器管脚定义

# 音谱定义
Tone_CL = [0, 131, 147, 165, 175, 196, 211, 248]        # 低C音符的频率
Tone_CM = [0, 262, 294, 330, 350, 393, 441, 495]        # 中C音的频率
Tone_CH = [0, 525, 589, 661, 700, 786, 882, 990]        # 高C音符的频率


# 第一首歌音谱
makerobo_song_1 = [ Tone_CM[3], Tone_CM[5], Tone_CM[6], Tone_CM[3], Tone_CM[2], Tone_CM[3], Tone_CM[5], Tone_CM[6],
                    Tone_CH[1], Tone_CM[6], Tone_CM[5], Tone_CM[1], Tone_CM[3], Tone_CM[2], Tone_CM[2], Tone_CM[3],
                    Tone_CM[5], Tone_CM[2], Tone_CM[3], Tone_CM[3], Tone_CL[6], Tone_CL[6], Tone_CL[6], Tone_CM[1],
                    Tone_CM[2], Tone_CM[3], Tone_CM[2], Tone_CL[7], Tone_CL[6], Tone_CM[1], Tone_CL[5] ]
# 第1首歌的节拍，1表示1/8拍
makerobo_beat_1 = [ 1, 1, 3, 1, 1, 3, 1, 1,
                    1, 1, 1, 1, 1, 1, 3, 1,
                    1, 3, 1, 1, 1, 1, 1, 1,
                    1, 2, 1, 1, 1, 1, 1, 1,
                    1, 1, 3 ]
# 第二首歌音谱
makerobo_song_2 = [ Tone_CM[1], Tone_CM[1], Tone_CM[1], Tone_CL[5], Tone_CM[3], Tone_CM[3], Tone_CM[3], Tone_CM[1],
                    Tone_CM[1], Tone_CM[3], Tone_CM[5], Tone_CM[5], Tone_CM[4], Tone_CM[3], Tone_CM[2], Tone_CM[2],
                    Tone_CM[3], Tone_CM[4], Tone_CM[4], Tone_CM[3], Tone_CM[2], Tone_CM[3], Tone_CM[1], Tone_CM[1],
                    Tone_CM[3], Tone_CM[2], Tone_CL[5], Tone_CL[7], Tone_CM[2], Tone_CM[1] ]

# 第2首歌的节拍，1表示1/8拍
makerobo_beat_2 = [ 1, 1, 2, 2, 1, 1, 2, 2,
                    1, 1, 2, 2, 1, 1, 3, 1,
                    1, 2, 2, 1, 1, 2, 2, 1,
                    1, 2, 2, 1, 1, 3 ]

# GPIO设置函数
def makerobo_setup():
    global  buzzer
    buzzer = PWM(Pin(makerobo_Buzzer), freq=0, duty=512)  # 无源蜂鸣器管脚定义

# 播放音乐函数
def playtone(frequency):
    buzzer.freq(frequency)


# 停止播放函数
def bequiet():
    buzzer.deinit()

# 循环函数
def makerobo_loop():
    while True:
        #    播放第一首歌音乐...
        for i in range(1, len(makerobo_song_1)):     # 播放第一首歌
            playtone(makerobo_song_1[i]) # 设置歌曲音符的频率
            sleep(makerobo_beat_1[i] * 0.5) # 延迟一个节拍* 0.5秒的音符


        sleep(1)   # 等待下一首歌。

        #    播放第二首歌音乐...
        for i in range(1, len(makerobo_song_2)):     # 播放第二首歌
            playtone(makerobo_song_2[i]) # 设置歌曲音符的频率
            sleep(makerobo_beat_2[i] * 0.5)     # 延迟一个节拍* 0.5秒的音符

        sleep(1)   # 等待下一首歌

# 程序入口
if __name__ == '__main__':
    makerobo_setup()
    try:
        makerobo_loop()
    except KeyboardInterrupt:  # 当按下Ctrl+C时，将执行destroy()子程序。
        bequiet()    # 停止播放

