#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：38_PIR.py
#  版本：V2.0
#  author: zhulin
#  说明：PIR 人体热释电实验
#####################################################
from machine import Pin,PWM
from utime import sleep

makerobo_rgbPins = {'Red':26, 'Green':25, 'Blue':32}  # RGB-LED 管脚定义
makerobo_pirPin = 27    # PIR人体热释电管脚PIN

# 初始化
def makerobo_setup():
    global pir_R, pir_G, pir_B
    global pir
    pir = Pin(makerobo_pirPin, Pin.IN) # 将makerobo_pirPin设置为输入
    
    pir_R = PWM(Pin(makerobo_rgbPins['Red']))
    pir_G = PWM(Pin(makerobo_rgbPins['Green']))
    pir_B = PWM(Pin(makerobo_rgbPins['Blue']))


    # 设置所有led作为pwm通道和频率到2KHz
    pir_R.freq(2000)   
    pir_G.freq(2000)
    pir_B.freq(2000)
    
# 定义映射值的映射函数。比如从0~255到0~100
def makerobo_MAP(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# 定义用于设置颜色的函数
def makerobo_setColor(color):
    # 配置三个led的亮度与输入的颜色值。
    # 区分颜色从“color” 变量修改
    R_val = (color & 0xFF0000) >> 16
    G_val = (color & 0x00FF00) >> 8
    B_val = (color & 0x0000FF) >> 0
    # 将颜色值从0~255映射到0~100
    R_val = round(makerobo_MAP(R_val, 0, 255, 0, 4095))    
    G_val = round(makerobo_MAP(G_val, 0, 255, 0, 4095))    
    B_val = round(makerobo_MAP(B_val, 0, 255, 0, 4095))    

    # 将映射的占空比值赋给相应的PWM通道来改变亮度。
    pir_R.duty(R_val)
    pir_G.duty(G_val)
    pir_B.duty(B_val)

# 循环函数
def makerobo_loop():
    while True:
        pir_val = pir.value()                  # 读取PIR模块管脚电平
        if pir_val==1:                         # 如果检测到为高电平
            makerobo_setColor(0xFFFF00)        # 设置RGB-LED灯
        else :
            makerobo_setColor(0x0000FF)        # 设置RGB—LED灯


# 程序入口
if __name__ == '__main__':
    makerobo_setup()   # 初始化
    makerobo_loop() # 调用循环函数

