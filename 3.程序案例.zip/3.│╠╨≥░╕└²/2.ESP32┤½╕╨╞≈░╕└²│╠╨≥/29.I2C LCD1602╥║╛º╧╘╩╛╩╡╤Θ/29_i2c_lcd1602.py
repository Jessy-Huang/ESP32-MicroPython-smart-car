#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：29_i2c_lcd1602.py
#  版本：V2.0
#  author: zhulin
#  说明：IIC LCD1602液晶显示器模块实验
#####################################################
from machine import Pin, I2C
from i2c_lcd import I2cLcd
from utime import sleep
# LCD 1602 I2C 地址
DEFAULT_I2C_ADDR = 0x27

# 初始化LCD1602液晶模块
def makerobo_setup():
    global lcd
    i2c = I2C(1,sda=Pin(26),scl=Pin(25),freq=400000)
    lcd = I2cLcd(i2c, DEFAULT_I2C_ADDR, 2, 16)  # 初始化(设备地址, 背光设置)
    lcd.putstr("Hello!!! \nMakerobo kit")       # 显示第一行信息及第二行信息
    sleep(2)                                    # 延时2S


# 循环函数
def makerobo_loop():
    makerobo_space = '                '  # 空显信息
    makerobo_greetings = 'makerobo ESP32 Pico kit! ^_^' # 显示提示信息
    makerobo_greetings = makerobo_space + makerobo_greetings # 显示信息拼接
    # 无线循环
    while True:
        makerobo_tmp = makerobo_greetings                    # 获取到显示信息
        for i in range(0, len(makerobo_greetings)):          # 逐一显示
            lcd.putstr(makerobo_tmp)                         # 逐个显示
            makerobo_tmp = makerobo_tmp[1:]
            sleep(0.8)                                       # 延时800ms
            lcd.clear()                                      # 清除显示

# 程序入口
if __name__ == "__main__":
    makerobo_setup()      # 初始化信息
    makerobo_loop()       # 循环显示信息
