#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：03_rgb_led.py
#  版本：V2.0
#  author: zhulin
# 说明：RGB-LED传感器实验
#---------------------------------------
from machine import Pin, PWM
from time import sleep

colors = [0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0xFF00FF, 0x00FFFF]

makerobo_R = 32
makerobo_G = 25
makerobo_B = 26

# 初始化程序
def makerobo_setup(Rpin, Gpin, Bpin):
    global pins
    global p_R, p_G, p_B
    pins = {'pin_R': Rpin, 'pin_G': Gpin, 'pin_B': Bpin}
    p_R = PWM(Pin(pins['pin_R']))  # 定义红色LED PWM
    p_G = PWM(Pin(pins['pin_G']))  # 定义绿色LED PWM
    p_B = PWM(Pin(pins['pin_B']))   # 定义蓝色LED PWM

    # 定义频率
    # 由于RGB三色模块每一个LED达到一定的亮度，需要的电流值是不一样，所以设置的频率有区别
    p_R.freq(2000)   # 设置频率为2KHz
    p_G.freq(1999)   # 设置频率为1999Hz
    p_B.freq(5000)   # 设置频率为2KHz

# 按比例缩放函数
def makerobo_pwm_map(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# 关闭RGB-LED灯
def makerobo_off():
    p_R.duty(0)
    p_G.duty(0)
    p_B.duty(0)

# 设置颜色
def makerobo_set_Color(col):   #  例如:col  = 0x112233
    R_val = (col &0xff0000) >> 16
    G_val = (col & 0x00ff00) >> 8
    B_val = (col & 0x0000ff) >> 0

    # 把0-255的范围同比例扩大到0~1023
    R_val = round(makerobo_pwm_map(R_val, 0, 255, 0, 1023))
    G_val = round(makerobo_pwm_map(G_val, 0, 255, 0, 1023))
    B_val = round(makerobo_pwm_map(B_val, 0, 255, 0, 1023))

    p_R.duty(R_val)     # 改变占空比
    p_G.duty(G_val)     # 改变占空比
    p_B.duty(B_val)     # 改变占空比

# 循环函数
def makerobo_loop():
    while True:
        for col in colors:
            makerobo_set_Color(col)  # 设置颜色
            sleep(1)            # 延时1s

# 程序入口
if __name__ == "__main__":
    makerobo_setup(makerobo_R, makerobo_G, makerobo_B) # 初始化设置函数
    makerobo_loop()                                    # 循环函数








