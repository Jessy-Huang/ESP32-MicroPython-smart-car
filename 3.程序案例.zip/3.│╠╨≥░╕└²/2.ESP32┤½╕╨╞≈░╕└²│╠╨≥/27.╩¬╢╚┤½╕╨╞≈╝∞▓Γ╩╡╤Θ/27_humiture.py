#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－湖南创乐博智能科技有限公司－－－－
#  文件名：27_humiture.py
#  版本：V2.0
#  author: zhulin
# 说明：湿度传感器检测实验
#####################################################
from machine import Pin
import dht
import utime

makerobo_pin = 27  # DHT11 温湿度传感器管脚定义

# GPIO口定义
def makerobo_setup():
    global dht_sensor
    dht_sensor=dht.DHT11(Pin(makerobo_pin))
    utime.sleep(1)    #首次启动停顿1秒让传感器稳定

# 循环函数
def loop():
    while True:
        dht_sensor.measure()  # 调用DHT类库中测量数据的函数
        T = dht_sensor.temperature()
        H = dht_sensor.humidity()
        if T is None:
            print(" sensor error")
        else:
            print('Makerobo Temp = {0:0.2f} *C'.format(T))    # 获取温度
            print('Makerobo Humidity = {0:0.2f} %'.format(H))   # 读取气压值
        # 如果延时时间过短，DHT11 温湿度传感器不工作
        utime.sleep_ms(2500)

# 程序入口
if __name__ == '__main__':
    makerobo_setup()
    loop()
