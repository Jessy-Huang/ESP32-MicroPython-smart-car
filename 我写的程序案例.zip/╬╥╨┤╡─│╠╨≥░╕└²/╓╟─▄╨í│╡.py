#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－极光编程－－－－
#  文件名：motor.py
#  版本：V2.0
#  author: Jessy
#  说明：智能小车实验
#####################################################
from machine import Pin, PWM
from utime import sleep

# 设置管脚PIN
left1_pin  = 15   
left2_pin   = 2
right1_pin  = 16
right2_pin  = 4
avoid_left_pin = 5       #寻迹
avoid_right_pin = 17
follow_left_pin = 19     #避障
follow_right_pin = 18

#全局变量
car_state = 'forward'    #车状态默认为forward

#motor初始化
def motor_setup():
    global motro_left1
    global motro_left2
    global motro_right1     
    global motro_right2
        
    motro_left1 = PWM(Pin(left1_pin), freq=20000, duty=0)  # 创建motor pwm对象，设置为输出模式 
    motro_left2 = PWM(Pin(left2_pin),freq=20000, duty=0)
    motro_right1 = PWM(Pin(right1_pin),freq=20000, duty=0)   
    motro_right2 = PWM(Pin(right2_pin),freq=20000, duty=0)

# 初始化寻迹避障模块GPIO口
def gpio_setup():
    global avoid_left
    global avoid_right
    global follow_left
    global follow_right
    avoid_left = Pin(avoid_left_pin,Pin.IN)
    avoid_right = Pin(avoid_right_pin,Pin.IN)
    follow_left = Pin(follow_left_pin,Pin.IN,Pin.PULL_UP)
    follow_right = Pin(follow_right_pin,Pin.IN,Pin.PULL_UP)
    
#方向函数
def turn_left():
    motro_left1.duty(400) # 输出高电平
    motro_left2.duty(0)
    motro_right1.duty(780) # 输出高电平
    motro_right2.duty(0)
def turn_right():
    motro_left1.duty(780) # 输出高电平
    motro_left2.duty(0)
    motro_right1.duty(400) # 输出高电平
    motro_right2.duty(0)
def fast_forward():
    motro_left1.duty(1000) # 输出高电平
    motro_left2.duty(0)
    motro_right1.duty(1000) # 输出高电平
    motro_right2.duty(0)
def slow_forward():
    motro_left1.duty(780) # 输出高电平
    motro_left2.duty(0)
    motro_right1.duty(780) # 输出高电平
    motro_right2.duty(0)
def backward():
    motro_left1.duty(0) # 输出高电平
    motro_left2.duty(780)
    motro_right1.duty(0) # 输出高电平
    motro_right2.duty(780)
def stop():
    motro_left1.duty(0) # 输出高电平
    motro_left2.duty(0)
    motro_right1.duty(0) # 输出高电平
    motro_right2.duty(0)

def led_show():
    pass
    
#通过红外模块获取方向
#红外传感器，二极管不断发射红外线，遇到白色反射回来，红外接收管饱和，输出低电平，否则输出高电平
#    (black line:1,white line:0)
def get_direction():
    direction = 'forward'
    if follow_left.value()==1 and follow_right.value()==0:   #左侧黑线，右侧白线
        direction = 'left'
    if follow_left.value()==0 and follow_right.value()==1:    #左侧白线，右侧黑线
        direction =  'right'
    if avoid_left.value()==1 or avoid_right.value()==1:       #前方任何一个红外遇到黑色（障碍物）
        direction =  'backward'

#自动控制，寻迹和避障
def auto_control():
    #global directions = {'forward':1,'backward':2,'left':3,'right':4,'stop':0}
    while True:
        slow_forward()
        direction = get_direction()
        if direction=='forward':
            slow_forward()
        elif direction=='backward':
            backward()
        elif direction=='left':
            turn_left()
        elif direction=='right':
            turn_right

#手动控制，通过红外遥控控制
def hand_control():
    pass


#主程序
motor_setup()
gpio_setup()
auto_control()




















