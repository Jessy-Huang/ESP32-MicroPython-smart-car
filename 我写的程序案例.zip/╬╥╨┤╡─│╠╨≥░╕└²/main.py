from machine import Pin
import utime

red = Pin(27,Pin.OUT)
red.off()

green = Pin(33,Pin.OUT)
while True:
    green.value(1)
    utime.sleep(1)
    green.value(0)
    utime.sleep(1)