### boot 按键按下led状态与前一次按键相反

from machine import Pin
import time

led = Pin(2,Pin.OUT)
button = Pin(23,Pin.IN)

def handler_interrupt(pin):
    led.value(not led.value())
button.irq(trigger=Pin.IRQ_FALLING,handler=handler_interrupt)