#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# －－－－极光编程－－－－
#  文件名：流水灯.py
#  author: Jessy
# 说明：LED流水灯实验
#---------------------------------------
from machine import Pin
import time

#引脚初始化
def LEDInit():
    led0 = Pin(32,Pin.OUT)
    led1 = Pin(33,Pin.OUT)
    led2 = Pin(25,Pin.OUT)
    led3 = Pin(26,Pin.OUT)
    led4 = Pin(27,Pin.OUT)
    led5 = Pin(14,Pin.OUT)
    led6 = Pin(12,Pin.OUT)
    led7 = Pin(13,Pin.OUT)

    #熄灭所有led
    led0.value(1)
    led1.value(1)
    led2.value(1)
    led3.value(1)
    led4.value(1)
    led5.value(1)
    led6.value(1)
    led7.value(1)
    
    return led0,led1,led2,led3,led4,led5,led6,led7

#方案1：顺序流水灯
def byOrders(led0,led1,led2,led3,led4,led5,led6,led7):
    while True:
        led0.value(0) #点亮led
        time.sleep(1)
        led0.value(1) #熄灭led
        time.sleep(1)
        
        led1.value(0)
        time.sleep(1)
        led1.value(1)
        time.sleep(1)
        
        led2.value(0)
        time.sleep(1)
        led2.value(1)
        time.sleep(1)
        
        led3.value(0)
        time.sleep(1)
        led3.value(1)
        time.sleep(1)
        
        led4.value(0)
        time.sleep(1)
        led4.value(1)
        time.sleep(1)
        
        led5.value(0)
        time.sleep(1)
        led5.value(1)
        time.sleep(1)
        
        led6.value(0)
        time.sleep(1)
        led6.value(1)
        time.sleep(1)
        
        led7.value(0)
        time.sleep(1)
        led7.value(1)
        time.sleep(1)
    
#方案2：从1数到8
def count(led0,led1,led2,led3,led4,led5,led6,led7):
    while True:
        led0.value(0) #点亮led
        time.sleep(1)
        led1.value(0) #点亮led
        time.sleep(1)
        led2.value(0) #点亮led
        time.sleep(1)
        led3.value(0) #点亮led
        time.sleep(1)
        led0.value(0) #点亮led
        time.sleep(1)
        led4.value(0) #点亮led
        time.sleep(1)
        led5.value(0) #点亮led
        time.sleep(1)
        led6.value(0) #点亮led
        time.sleep(1)
        led7.value(0) #点亮led
        time.sleep(1)
        
        #熄灭所有led
        led0.value(1)
        led1.value(1)
        led2.value(1)
        led3.value(1)
        led4.value(1)
        led5.value(1)
        led6.value(1)
        led7.value(1)
        time.sleep(2)
    
# 程序入口
if __name__ == "__main__":
    led0,led1,led2,led3,led4,led5,led6,led7 = LEDInit()
    #byOrders(led0,led1,led2,led3,led4,led5,led6,led7)
    count(led0,led1,led2,led3,led4,led5,led6,led7)














