from machine import Pin,PWM
import time

pin = Pin(18,Pin.OUT)
buzzer = PWM(pin)
buzzer.freq(1047)
buzzer.duty(50)
time.sleep(1)
buzzer.duty(0)
buzzer.deinit()

