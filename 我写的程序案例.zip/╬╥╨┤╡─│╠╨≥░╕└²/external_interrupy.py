from machine import Pin
import time

led = Pin(32,Pin.OUT)
button = Pin(0,Pin.IN)

def button_blink_led(num,t_on,t_off,msg):
    counter = 0
    while counter<num:
        led.value(0)
        time.sleep(t_on)
        led.value(1)
        time.sleep(t_off)
        counter += 1
    print(msg)

while True:
    if button.value()==0:
        button_blink_led(10,0.25,0.5,'Done.')