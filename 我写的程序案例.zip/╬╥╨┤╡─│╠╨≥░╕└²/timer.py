#esp32有4个timer，0-3
from machine import Pin,Timer

led = Pin(22,Pin.OUT)

tim0 = Timer(0)

#方法1
# tim0.init(period=2000,mode=Timer.PERIODIC,callback=lambda t: led.value(not led.value())) #每2s闪烁一次
##Timer.PERIODIC可出发多次，Timer.ONE_SHOT只出发一次

#方法2
def handle_callback(timer):
    led.value(not led.value())
    
tim0.init(period=500,mode=Timer.PERIODIC,callback=handle_callback) #每2s闪烁一次