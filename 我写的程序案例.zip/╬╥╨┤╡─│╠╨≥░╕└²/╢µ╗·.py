# 控制舵机转动任意角度，接线，黄色线为数据线，中间红色线为vcc，黑色线为gnd

from machine import Pin,PWM
import time

p23 = Pin(23,Pin.OUT)
pwm = PWM(p23)
pwm.freq(50)

def map(x,in_min,in_max,out_min,out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

def turn_clockwise():
    for i in range(0,181,10):
        pwm.duty(map(i,0,180,20,120))
        time.sleep(0.5)

def turn_anticlockwise():
    for i in range(180,-1,-10):
        pwm.duty(map(i,0,180,20,120))
        time.sleep(0.5)
 
#转动至任意角度 
def servo_toAngle(pin,angle):
    pin.duty(map(angle,0,180,20,120))

#变化任意角度
def servo_changeAngle(pin,angle_init,angle_change):
    angle = angle_init + angle_change
    pin.duty(map(angle,0,180,20,120))