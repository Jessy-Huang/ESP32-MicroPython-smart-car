# 控制两个舵机转动

from machine import Pin,PWM,Timer
import time

#1.创建引脚对象
p22 = Pin(22,Pin.OUT)
p23 = Pin(23,Pin.OUT)

#2.创建servo对象并将PWM驱动绑定引脚
servo1 = PWM(p22)
servo2 = PWM(p23)
#   初始化servo对象，20ms脉冲外部中断，初始化至0°
servo1.init(freq=50,duty=20)
servo2.init(freq=50,duty=20)

#3.创建Timer对象
tim1 = Timer(0)
tim2 = Timer(1)
#回调函数
def handle_tim1(timer):
    global is_tim1
    is_tim1 = True
def handle_tim2(timer):
    global is_tim2
    is_tim2 = True
#初始化timer对象
tim1.init(period=100,mode=Timer.PERIODIC,callback=handle_tim1) #0.1s
tim2.init(period=200,mode=Timer.PERIODIC,callback=handle_tim2)

#全局变量
is_tim1 = False
is_tim2 = False
angle1 = 0
angle2 = 0


def map(x,in_min,in_max,out_min,out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)
#转动至任意角度 
def servo(pin,angle):
    pin.duty(map(angle,0,180,20,120))
    
#Main loop
while True:
    if(is_tim1==True):
        is_tim1=False
        servo(servo1,angle1)
        if angle1<180:
            angle1 += 5
    if(is_tim2==True):
        is_tim2=False
        servo(servo2,angle2)
        if angle2<180:
            angle2 += 5
    
    











