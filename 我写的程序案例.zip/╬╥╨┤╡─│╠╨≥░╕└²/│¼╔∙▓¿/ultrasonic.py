from machine import Pin,PWM
import time
import hcsr04

ultrasonic = hcsr04.HCSR04(trigger_pin=13,echo_pin=12,echo_timeout_us=1000000)
led = Pin(33,Pin.OUT)
buzzer = PWM(Pin(32,Pin.OUT))
buzzer.freq(4186)
buzzer.duty(0)

while True:
    distance = ultrasonic.distance_cm()
    print('distance ',distance,'cm')
    if distance <= 10:
        buzzer.duty(512)
        led.value(0)  #点亮
    else:
        buzzer.duty(0)
        led.value(1)  #熄灭
    time.sleep_ms(1000)