#oled scl->G22 or G32.sda -> G21

from machine import Pin,I2C
import ssd1306

scl = Pin(22,Pin.OUT,Pin.PULL_UP)
sda = Pin(21,Pin.OUT,Pin.PULL_UP)

i2c = I2C(scl=scl,sda=sda,freq=400000)

oled = ssd1306.SSD1306_I2C(128,64,i2c,addr=0x3C)

def print_text(msg,x,y,clear=1):
    if clear:
        oled.fill(0)
    oled.text(msg,x,y)
    oled.show()
    
