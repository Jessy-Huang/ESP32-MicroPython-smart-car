import machine

led = machine.Pin(22,machine.Pin.OUT)
button = machine.Pin(0,machine.Pin.IN)

while True:
    if(button.value()==0): #按下时button的值为0
        led.value(1)
    else:
        led.value(0)