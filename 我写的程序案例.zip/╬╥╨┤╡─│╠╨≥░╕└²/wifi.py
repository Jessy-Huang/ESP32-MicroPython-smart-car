#如何使用Esp8266/ESP32上的MicroPython连接Wi-Fi网络
#首先导入network模块，以获取建立Wi-Fi网络连接所需的所有功能
import network

#以工作站 (station) 模式运行，需要创建一个工作站Wi-Fi接口的实例
#工作站模式（ESP32连接到路由器）， AP模式提供接入服务（其他设备连接到ESP32）。
station = network.WLAN(network.STA_IF)

#在工作站对象上调用激活方法并以True作为输入值传递来激活网络接口
station.active(True)

#使用connect方法连接到Wi-Fi网络。该方法以SSID（网络名称）和密码作为输入值
station.connect("此处改为你的无线网名称", "无线网密码")

#调用isconnected方法确认连接，如果设备已连接Wi-Fi网络，则返回true
station.isconnected()

#调用ifconfig方法返回IP地址、子网掩码、网关和DNS作为输出参数
IP_info=station.ifconfig()

print("IP地址："+IP_info[0])
print("子网掩码："+IP_info[1])
print("网关："+IP_info[2])
print("DNS："+IP_info[3])