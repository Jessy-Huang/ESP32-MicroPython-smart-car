#外设LED闪烁
from machine import Pin
import time
led = Pin(22,Pin.OUT)
while True:
    led.on()
    time.sleep(1)
    led.off()
    time.sleep_ms(500)
    led.value(1)
    time.sleep_us(1000000)
    led.value(0)
    time.sleep(0.5)
