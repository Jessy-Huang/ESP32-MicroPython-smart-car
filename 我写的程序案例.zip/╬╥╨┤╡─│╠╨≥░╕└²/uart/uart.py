# esp32有3个串口，Port0((flashing)):Pin1 Pin3  Port1(spi):Pin9 Pin10
#   Port2:Pin16 Pin17  rx和tx也可以换到其他引脚
  
from machine import Pin,UART

led = Pin(2,Pin.OUT)
uart = UART(2,11520)

strMsg = ''

while True:
    if uart.any() > 0:
        strMsg = uart.read()
        print(strMsg)
        
        if 'on' in strMsg:
            led.value(0)
            uart.write('Turning on led')
            print('Turning on led')
            
        elif 'off' in strMsg:
            led.value(1)
            uart.write('Turning off led')
            print('Turning off led')
            
        else:
            uart.write('Invalid command')
            print(('Invalid command'))