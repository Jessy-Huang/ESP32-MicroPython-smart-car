from IR_REMOTE import IR

def user_callback(ir, address, command, repeat):
    print(address, command, repeat)
    #此处可添加自定义代码
    
ir = IR(tim = 3, channel = 4, pin = pyb.Pin.board.X4)
ir.ir_remote_callback_set(user_callback)
