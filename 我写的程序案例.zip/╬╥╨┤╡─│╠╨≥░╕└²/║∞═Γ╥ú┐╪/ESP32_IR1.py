from IRremote import IRReceiver

receiver = IRReceiver(33)
receiver.callback = print
receiver.daemon()