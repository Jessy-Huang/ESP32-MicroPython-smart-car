# micropython-IR-NEC

## 介绍

适用于Micropython的红外遥控库，NEC码，支持中断和读取两种模式。[[micropython-necir\]](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FMattMatic%2Fmicropython-necir)的基础上进行了大量改写。上述仓库会在使用灵敏度较高的红外接收头时因环境红外光干扰而解码出错误的信息。

目前使用红外解码器IRM-H638T_TR2进行了测试。

## 使用方法

### 1. 中断模式

```python
from IR_REMOTE import IR

def user_callback(ir, address, command, repeat):
    print(address, command, repeat)
    #此处可添加自定义代码
    
ir = IR(tim = 3, channel = 4, pin = pyb.Pin.board.X4)
ir.ir_remote_callback_set(user_callback)
```

### 2. 读取模式

```Python
from IR_REMOTE import IR
    
ir = IR()
print(ir.ir_remote_get(tim = 3, channel = 4, pin = pyb.Pin.board.X4))
#此处可添加自定义代码
```

### 3.参数

- address:遥控地址
- command:遥控指令
- repeat:遥控是否一致按下而重复发送
- ir:class IR的实例
- tim:红外解码器连接的引脚使用的定时器
- channel:红外解码器连接的引脚使用的定时器通道
- pin:红外解码器连接的引脚

## 注意

1. 中断模式和读取模式不要同时使用。例如配置了中断回调函数ir.ir_remote_callback_set()，后调用ir.ir_remote_get()，会返回错误的address, command, repeat。
2. 读取模式只能读取到调用ir_remote_get()前最后一次获取的遥控码，两次调用ir_remote_get()中间的会被覆盖掉。
3. 读取模式下，有可能第一次读取repeat就为True，这是由于上注意2中的原因，即第一次的遥控数据没有读取，读取时已经是多次重复遥控了。
4. 磨人的定时器频率为84Mhz，如果你的定时器为168Mhz等频率请修改28行中的prescaler = (840 - 1)为prescaler = (您的定时器频率x10 - 1)。