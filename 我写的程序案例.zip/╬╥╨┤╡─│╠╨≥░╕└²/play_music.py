
from machine import Pin,PWM
import time

p23 = Pin(5,Pin.OUT)

def play(pin,melodies,delays,duty):
    pwm = PWM(pin)
    for note in melodies:
        pwm.freq(note)
        pwm.duty(duty)
        time.sleep(delays)
    pwm.duty(0)
    pwm.deinit()
    
