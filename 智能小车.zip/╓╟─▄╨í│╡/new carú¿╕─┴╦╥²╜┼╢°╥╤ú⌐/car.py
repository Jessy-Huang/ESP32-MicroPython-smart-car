from machine import Pin
import time

# 设置管脚PIN
motro_left1  = Pin(13,Pin.OUT)   
motro_left2  = Pin(12,Pin.OUT) 
motro_right1  = Pin(27,Pin.OUT) 
motro_right2  = Pin(14,Pin.OUT) 

#方向函数
def turn_left():  #左边的轮子不转右边的轮子转，车子就会向做转
    motro_left1.value(0) # 输出高电平
    motro_left2.value(0)
    motro_right1.value(1) # 输出高电平
    motro_right2.value(0)
def turn_right():
    motro_left1.value(1) # 输出高电平
    motro_left2.value(0)
    motro_right1.value(0) # 输出高电平
    motro_right2.value(0)
def forward():
    motro_left1.value(1) # 输出高电平
    motro_left2.value(0)
    motro_right1.value(1) # 输出高电平
    motro_right2.value(0)
def backward():
    motro_left1.value(0) # 输出高电平
    motro_left2.value(1)
    motro_right1.value(0) # 输出高电平
    motro_right2.value(1)
def stop():
    motro_left1.value(0) # 输出高电平
    motro_left2.value(0)
    motro_right1.value(0) # 输出高电平
    motro_right2.value(0)
    
def smart_car():
    forward()
    time.sleep(5)
    stop()
    turn_left()
    time.sleep(1)
    stop()
    turn_right()
    time.sleep(1)
    stop()
    backward()
    time.sleep(5)
    stop()
    
if __name__=='__main__':
    smart_car()
    
    
    
    
    